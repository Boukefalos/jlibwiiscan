﻿using System;
using System.Threading;
using System.Diagnostics;
using WiimoteLib;

namespace wiimotelibpoll
{
    static class wiimotelibpoll
    {
        static void FlashLeds(int count,Wiimote wm)
        {
            if (count % 5 != 0) return;

            switch ((count/5) % 6 )
                {
                    case 0:
                        wm.SetLEDs(true, false, false, false);
                        break;

                    case 1:
                        wm.SetLEDs(false,true, false, false);
                        break;
                    case 2:
                        wm.SetLEDs(false, false, true, false);
                        break;
                    case 3:
                        wm.SetLEDs(false, false, false, true);
                        break;
                    case 4:
                        wm.SetLEDs(false, false, true, false);
                        break;
                    case 5:
                        wm.SetLEDs(false, true, false, false);
                        break;
                    default:
                        Debug.Assert(false);
                        break;
                }
        }

        [STAThread]
        static int Main(string[] args)
        {
            String env = "WIISCANIPC";
            Wiimote wm = new Wiimote();

            try
            {
                string e = Environment.GetEnvironmentVariable(env, EnvironmentVariableTarget.User);
                int r = Int16.Parse(e);

                if (r != -3) throw new Exception("mismatch in poll IPC");

                int retries = 4, c = 0;
                while (c == 0 && --retries >= 0)
                {
                    wm.Connect();
                    wm.GetStatus();
                    c = wm.GetNumConnectRemotes();
                    if (c == 0)
                    {
                        wm.Disconnect();
                        Thread.Sleep(500);
                    }
                }

                if (c == 0) throw new Exception("Not connected");
                Debug.Assert(c > 0);

                // flag, that polling is connected now
                Environment.SetEnvironmentVariable(env, "1", EnvironmentVariableTarget.User);
                  
                r = 0;
                while (true)
                {
                    // Get and set some wiimote status
                    wm.GetStatus();
                    FlashLeds(r, wm);

                    // The Environment makes my "screen flash" (annying .net feature??), so i disable them
                    //if (r!=0 && Int16.Parse(Environment.GetEnvironmentVariable(env, EnvironmentVariableTarget.User)) < 0) break; 
                    //Environment.SetEnvironmentVariable(env, r.ToString(), EnvironmentVariableTarget.User);
                    Thread.Sleep(400);

                    ++r;
                    if (r > 100000) r = 0;
                }

                System.Console.WriteLine("  ** warning: disconnected");
                System.Console.WriteLine("Done [OK]");

                Environment.SetEnvironmentVariable(env, "-1", EnvironmentVariableTarget.User);
                return -1;
            }
            catch { }
            finally { wm.Disconnect(); }

            System.Console.WriteLine("  ** error: encountered an exception");
            System.Console.WriteLine("Done [ERROR]");

            Environment.SetEnvironmentVariable(env, "-1", EnvironmentVariableTarget.User);
            return -1;
        }
    }
}
