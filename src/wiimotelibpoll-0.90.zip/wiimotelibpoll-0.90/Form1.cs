﻿using System;
using System.Text;
using System.Windows.Forms;

namespace wiimotelibpoll
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
    }
}
