// Copyright © 2009 MergeIt, Aps.
//
// License LGPLv3+: GNU lesser LGPL version 3 or later <http://gnu.org/licenses/lgpl.html>.
// This is free software: you are free to change and redistribute it.
// There is NO WARRANTY, to the extent permitted by law.
//
//	This file is part of wiiscan.
//
//  wiiscan is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  any later version.
//
//  wiiscan is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with wiiscan.  If not, see <http://www.gnu.org/licenses/>.

#include "wiiscan.h"

int main(int argc,char** argv)
{
	return Wiiscan::main(argc,argv);
}