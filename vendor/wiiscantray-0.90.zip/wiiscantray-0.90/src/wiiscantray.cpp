// Copyright � 2009 MergeIt, Aps.
//
// License LGPLv3+: GNU lesser LGPL version 3 or later <http://gnu.org/licenses/lgpl.html>.
// This is free software: you are free to change and redistribute it.
// There is NO WARRANTY, to the extent permitted by law.
//
//	This file is part of wiiscan.
//
//  wiiscan is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  any later version.
//
//  wiiscan is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with wiiscan.  If not, see <http://www.gnu.org/licenses/>.

#pragma warning(disable:4786) 

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <windows.h>

#define  TOOLSFUN_QUIET_WIN32_SYSTEM // use WinExec instead of system  
#include "resource.h"
#include "systemtraysdk.h"
#include "wiiscan.h"
#include "process.h"

#define MAX_LOADSTRING 100
#define	WM_ICON_NOTIFY WM_APP+10

// Global Variables:
HINSTANCE hInst;								// current instance
char szTitle[MAX_LOADSTRING];					// The title bar text
char szWindowClass[MAX_LOADSTRING];			// The title bar text

CSystemTray      g_trayicon;
Configfile       g_config(Wiiscan::DEFAULT_configfile); 
volatile int     g_exitflag=0;
volatile bool    g_launch_wb=false;
bool             g_debug=g_config.Initialize<bool>("option_debug",false);
extern int       g_automode_state;
const string wiimotelibpoll_exe="wiimotelibpoll.exe";

string GetCurrentDir()
{
	FUNSTACK;
	char buff[16*1024];
	if(GetCurrentDirectory(16*1024,buff)==0) throw_("GetCurrentDirectory() failed");
	return tostring(buff);
}

string GetConfigStringMessage(const string& e)
{
	FUNSTACK;
	const pair<bool,string> p=g_config.GetConfig<string>(e);
	if (!p.first) Message("Warning...","Configuration file does not contain a <" + e + "=...> entry, or entry is empty");
	return p.second;
}

void UpdateIconCallback(const int n)
{
	FUNSTACK;
	switch(n+1){
		case 0 : g_trayicon.SetIcon(IDI_SCAN_00); break;
		case 1 : g_trayicon.SetIcon(IDI_SCAN_01); break;
		case 2 : g_trayicon.SetIcon(IDI_SCAN_01); break;
		case 3 : g_trayicon.SetIcon(IDI_SCAN_02); break;
		case 4 : g_trayicon.SetIcon(IDI_SCAN_03); break;
		case 5 : g_trayicon.SetIcon(IDI_SCAN_03); break;
		case 6 : g_trayicon.SetIcon(IDI_SCAN_04); break;
		case 7 : g_trayicon.SetIcon(IDI_SCAN_05); break;
		//case 8 : g_trayicon.SetIcon(IDI_SCAN_06); break;
		//case 9 : g_trayicon.SetIcon(IDI_SCAN_07); break;
		default: g_trayicon.SetIcon(IDI_SCAN_07); break;
	}
}

void RunWhiteboard(const bool killonly)
{		
	FUNSTACK;
	if (g_debug) Wiiscan::log << "## Wiiscantray::RunWhiteboard(" << killonly << ")" << endl;

	const string wb=strip(GetConfigStringMessage("whiteboard_software"),'"');
	if (wb!=""){
		const string e=tail(tail(tail(wb,':'),'/'),'\\');
		if (killonly){
			if (e!=""){
				DWORD id=GetProcessID(e);
				while(id!=0){
					KillProcessID(id);
					id=GetProcessID(e);
				}
			}
		} else {
			// fireup whiteboard software
			if (GetProcessCount(wb)>0) return;  
			else if (0!=SystemWin(wb)) throw_("could not launch executable <" + wb + ">");

			const int option_sleep_after_startwhiteboard=g_config.Initialize<int>("option_sleep_after_startwhiteboard",4000);
			static bool firstrun=true;
			if (firstrun && g_debug) Wiiscan::log << "##   RunWhiteboard:     option_sleep_after_startwhiteboard=" << option_sleep_after_startwhiteboard << endl;
			firstrun=false;
			Sleep(option_sleep_after_startwhiteboard);
		}
	}
}

int CheckGlobalFlags()
{
	FUNSTACK;
	// too verbose: if (g_debug) Wiiscan::log << "## Wiiscantray::CheckGlobalFlags()" << endl;
	if (g_exitflag>0) {
		if (g_debug) Wiiscan::log << "##   CheckGlobalFlags:  got exit message" << endl;
		g_exitflag=2; 
		return -1;
	}
	else if (g_launch_wb) {
		if (g_debug) Wiiscan::log << "##   CheckGlobalFlags:  got launch wb message" << endl;
		g_launch_wb=false; 
		RunWhiteboard(false); 		
		return 1;
	}
	else return 0;
}

int DoSleep(const int sleep)
{
	FUNSTACK;
	if (g_debug) Wiiscan::log << "## Wiiscantray::DoSleep(" << sleep << ")" << endl;

	assert(sleep>0);
	int s=sleep>1000 ? sleep/100 : 1;
	while(--s>=0){
		Sleep(sleep>1000 ? 100 : sleep);
		if (CheckGlobalFlags()==-1) return -1;				 
	}
	return 0;
}


int Autoscan()
{
	FUNSTACK;
	if (g_debug) Wiiscan::log << "## Wiiscantray::Autoscan()" << endl;

	Wiiscan::g_automode_callback=&UpdateIconCallback;
	g_trayicon.SetIcon(IDI_SCAN_00);
	
	// generate dummy argv array	
	char* argv[]={"wiiscantray","-nowb","-l","none",};	
	const int r=Wiiscan::main(4,argv);
	
	if (r==0) g_trayicon.SetIcon(IDI_SCAN_07);
	else      g_trayicon.SetIcon(IDI_WIISCANICON_INV);

	if (g_debug) Wiiscan::log << "##   Autoscan:          returned r=" << r << endl;

	Wiiscan::g_automode_callback=0;
	return r;
}

void SetPollReg(const int n)
{
	if (!Registry::SetKey("HKEY_CURRENT_USER\\Environment\\WIISCANIPC",tostring(n))) throw_("failed to set registry entry");
}

int Wiimotelibpoll(const int sleep_between_poll_retries,bool startwb)
{
	FUNSTACK;
	if (g_debug) Wiiscan::log << "## Wiiscantray::Wiimotelibpoll()" << endl;
	assert( sleep_between_poll_retries>10 );

	KillAllProcesses(wiimotelibpoll_exe);
	SetPollReg(-3);

	const int n=SystemWin(wiimotelibpoll_exe);
	if (g_debug) Wiiscan::log << "##   Wiimotelibpoll:    SystemWin returned n=" << n << endl;
	if (n!=0) throw_("error execution <" + wiimotelibpoll_exe + ">");

	int r=-3;
	bool iconsetted=false;
	do {
		Sleep(100);
		if (CheckGlobalFlags()==-1) return -2;
		if (GetProcessID(wiimotelibpoll_exe)==0) break; // poll not running 

		const string t=Registry::GetKey("HKEY_CURRENT_USER\\Environment\\WIISCANIPC");
		r=totype<int>(t);

		if (r>=0) {
		  if (startwb)    {startwb=false; g_launch_wb=true;}
		  if (!iconsetted){iconsetted=true; g_trayicon.SetIcon(IDI_WIISCANICON);}
		}
	} while( r>=0 || r==-3 );

	// clean
	g_trayicon.SetIcon(IDI_WIISCANICON_INV);
	KillAllProcesses(wiimotelibpoll_exe);
	return -1;
}

DWORD WINAPI Autoscan_loop(LPVOID)
{	
	FUNSTACK;
	{
		// call wiiscan Usage => enable logging
		char* argv[]={"wiiscantray","-?",};	
		Wiiscan::main(2,argv);
	}
		
	if (g_debug) Wiiscan::log << "## Wiiscantray::Autoscan_loop()" << endl;

	g_config.Checkfilechange(); 
	g_debug=g_config.Initialize<bool>("option_debug",false);

	const int poll_retries              =g_config.Initialize<int>("option_tray_pool_retries",3);
	const int sleep_between_poll_retries=g_config.Initialize<int>("option_tray_sleep_between_pool_retries",200);
	const int sleep_between_poll_loops  =g_config.Initialize<int>("option_tray_sleep_between_pool_loops",2000);
	const int sleep_before_final_connect=g_config.Initialize<int>("option_sleep_before_final_connect",1500);
	const bool startwb                  =g_config.Initialize<bool>("option_startwhiteboard",false);

	if (g_debug) Wiiscan::log << "##  Autoscan_loop:   wiiscantray: variables" << endl;
	if (g_debug) Wiiscan::log << "##   Autoscan_loop:     option_poll_retries               =" << poll_retries << endl;
	if (g_debug) Wiiscan::log << "##   Autoscan_loop:     option_sleep_between_poll_retries =" << sleep_between_poll_retries << endl;
	if (g_debug) Wiiscan::log << "##   Autoscan_loop:     option_sleep_between_poll_loops   =" << sleep_between_poll_loops  << endl;
	if (g_debug) Wiiscan::log << "##   Autoscan_loop:     option_sleep_before_final_connect =" << sleep_before_final_connect << endl;
	if (g_debug) Wiiscan::log << "##   Autoscan_loop:     option_startwhiteboard            =" << startwb << endl;
	
	unsigned long long loop=0;
	while(true) {
		SetNiceLevel(15);
		if (g_debug) Wiiscan::log << "##   Autoscan_loop:     loop="<< loop << endl;

		++loop;
		if(Wiimotelibpoll(sleep_between_poll_retries,startwb)==-2) return 0;

		if (CheckGlobalFlags()==-1) return 0;
		if (g_debug) Wiiscan::log << "##   Autoscan_loop:     not connected OK" << endl;

		if (CheckGlobalFlags()==-1) return 0;
		while(Autoscan()!=0) DoSleep(sleep_between_poll_loops);

		if (g_debug) Wiiscan::log << "##   Autoscan_loop:     connected OK" << endl;

		g_trayicon.SetIcon(IDI_WIISCANICON);		
		Sleep(sleep_before_final_connect);
	}
	return 0;
}

LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	FUNSTACK;
	switch (message) {
		case WM_INITDIALOG:	return TRUE;
		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) {
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
	return FALSE;
}

void ExitTray(HWND hWnd)
{	
	FUNSTACK;
	// an exit in the middle of a wiimotepoll may break the wiimote connection, do a nice exit instead
	g_exitflag=1;
	int retries=100;
	while(g_exitflag!=2 && --retries>0) {Sleep(100);}

	KillAllProcesses(wiimotelibpoll_exe);
	SetPollReg(-4);
	DestroyWindow(hWnd);
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	FUNSTACK;
	int wmId, wmEvent;
	switch (message) 
	{
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			// Parse the menu selections:
			switch (wmId) {
				//case IDM_AUTO: Autoscan_loop(); break; // moved to autoscan thread
				case IDM_WHITEBOARD:      g_launch_wb=1; break; 
				case IDM_WHITEBOARD_KILL: RunWhiteboard(true); break;
				case IDM_DISPLAYLOG: {
					const string f=GetConfigStringMessage("option_logfile");
					if (f!=""){
						const string log=GetCurrentDir() + "\\" + strip(f,'"');
						if (!FileExists(log)) Message("Warning...","The logfile <" + log + "> does not exist");
						else SystemWin("notepad " + log );
					}
                    break;
				}
				case IDM_RESETLOG: {
					const string log=GetCurrentDir() + "\\" + strip(GetConfigStringMessage("option_logfile"),'"');
					if (FileExists(log)) {
						if (g_debug) Wiiscan::log.clear();
						if (g_debug) Wiiscan::log.writelogheader("logged cleared");
					}					
					break;
				}
				case IDM_ABOUT: DialogBox(hInst,(LPCTSTR)IDD_ABOUTBOX,hWnd,(DLGPROC)About); break;
				case IDM_EXIT:  ExitTray(hWnd); break;
				default:        return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;
        case WM_ICON_NOTIFY: return g_trayicon.OnTrayNotification(wParam, lParam); 
		case WM_PAINT: 		 break;
		case WM_DESTROY:     PostQuitMessage(0); break;
		default:	         return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

ATOM MyRegisterClass(HINSTANCE hInstance)
{
	FUNSTACK;
	WNDCLASSEX wcex;
	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_WIISCANICON);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= (LPCSTR)IDC_WIISCANTRAY;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_WIISCANICON);

	return RegisterClassEx(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	FUNSTACK;
	hInst = hInstance; // Store instance handle in our global variable
	HWND hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);   
	if (!hWnd) return FALSE;

	// Create the tray icon
	if (!g_trayicon.Create(hInstance,hWnd,WM_ICON_NOTIFY,"Wiiscan monitor",::LoadIcon(hInstance,(LPCTSTR)IDI_WIISCANICON),IDR_POPUP_MENU)) return FALSE;
	g_trayicon.SetIcon(IDI_WIISCANICON_INV);
	
	//ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	return TRUE;
}

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
	FUNSTACK;
	try{
		SetPollReg(-4);

		int retries=20,n;
		do{
			if (retries!=20) Sleep(100);
			const DWORD id=GetCurrentProcessId();
			const PROCESSENTRY32 p32=GetProcessInfo(id);
			n=GetProcessCount(p32.szExeFile);
		} while(n>1 && --retries>0);

		if (n>1) {
			Message("Error...","Wiiscantray is already running\n\nAborting...");
			return -1;
		}

		// Initialize global strings
		LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
		LoadString(hInstance, IDC_WIISCANTRAY, szWindowClass, MAX_LOADSTRING);
		MyRegisterClass(hInstance);

		// Perform application initialization:
		if (!InitInstance (hInstance, nCmdShow)) return FALSE;

		HACCEL hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_WIISCANTRAY);
		
		DWORD tid=0;
		DeviceAutoClose<HANDLE,BOOL> t(CreateThread(0,0,Autoscan_loop,0,0,&tid),CloseHandle);
		if (t()==NULL) throw_("Error creating autoscan thread");		

		// Main message loop:
		MSG msg;
		while (GetMessage(&msg, NULL, 0, 0)) {
			if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) {
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}

		return msg.wParam;
	}
	CATCH_ALL;

	KillAllProcesses(wiimotelibpoll_exe);
	SetPollReg(-4);
	return -1;
}