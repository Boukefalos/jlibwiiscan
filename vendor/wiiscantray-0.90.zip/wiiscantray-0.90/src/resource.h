//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by wiiscantray.rc
//
#define IDC_MYICON                      2
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_WIISCANICON                 107
#define IDC_WIISCANTRAY                 109
#define IDR_MAINFRAME                   128
#define IDR_POPUP_MENU                  130
#define IDM_WHITEBOARD                  32774
#define IDM_WHITEBOARD_KILL             32775
#define IDM_DISPLAYLOG                  32776
#define IDM_RESETLOG                    32777
#define ID_APP_ABOUT                    0xE140
#define ID_APP_EXIT                     0xE141
#define IDC_STATIC                      -1
#define IDI_SCAN_00                     34000
#define IDI_SCAN_01                     34001
#define IDI_SCAN_02                     34002
#define IDI_SCAN_03                     34003
#define IDI_SCAN_04                     34004
#define IDI_SCAN_05                     34005
#define IDI_SCAN_06                     34006
#define IDI_SCAN_07                     34007
#define IDI_SCAN_08                     34008
#define IDI_WIISCANICON_INV				34100	

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
